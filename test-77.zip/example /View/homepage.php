<?php 

echo "homepage"

?> 
